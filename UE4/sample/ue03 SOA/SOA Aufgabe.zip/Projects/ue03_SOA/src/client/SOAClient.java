package client;

/**
 * Class that will starte the Client GUI.
 *
 * @author Paul Pfeiffer-Vogl(ppfeiffer@student.tgm.ac.at) & Harun Koyuncu(hkoyuncu@student.tgm.ac.at)
 * @version 24-Nov-2012
 */
public class SOAClient {
    public static void main(String[] args) {
        // bring up the GUI
        new MyFrame();
    }
}
