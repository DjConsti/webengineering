
	How To Use:
	-------------
	
	1) Please change the configuration file "msqlConnection.xml" to our own
	   connection settings.
	   
	2) Copy the "msqlConnection.xml" to the domain folder of the used glassfish server.
	   For further information please take a look at the attached protocol.
	
	3) Start the mysql service and create the needed schema.


	Problems ?
		-> RTFM